package appointmentService;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.util.Calendar;
import java.util.Date;

public class AppointmentServiceTest {

    // Helper method: creates a valid future date
    private Date getFutureDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 1);
        return cal.getTime();
    }

    // Test adding a valid appointment
    @Test
    public void testAddAppointmentSuccess() {
        AppointmentService service = new AppointmentService();

        service.addAppointment("100", getFutureDate(), "Follow-up appointment");

        assertEquals(1, service.getAppointments().size());
        assertEquals("Follow-up appointment", service.getAppointments().get(0).getDescription());
    }

    // if appointmentId already exists, throw an exception
    @Test
    public void testAddAppointmentDuplicateId() {
        AppointmentService service = new AppointmentService();

        service.addAppointment("100", getFutureDate(), "Follow-up appointment");

        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment("100", getFutureDate(), "Follow-up appointment");
        });
    }

    // Test deleting an appointment that already exists
    @Test
    public void testDeleteAppointmentSuccess() {
        AppointmentService service = new AppointmentService();

        service.addAppointment("100", getFutureDate(), "Follow-up appointment");
        service.deleteAppointment("100");

        assertEquals(0, service.getAppointments().size());
    }

    // if deleting an appointment that does not exist, throw an exception
    @Test
    public void testDeleteAppointmentNotFound() {
        AppointmentService service = new AppointmentService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment("999");
        });
    }
}
