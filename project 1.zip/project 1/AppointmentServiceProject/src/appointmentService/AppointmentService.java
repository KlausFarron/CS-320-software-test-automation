package appointmentService;

import java.util.ArrayList;
import java.util.List;
import java.util.Date;

/*
 * The AppointmentService class to manage Appointment objects
 * 
 * - Adds new appointments with a unique ID
 * - Deletes appointments by appointment ID
 * - Stores appointments in an in-memory list
 */

public class AppointmentService {

    // List to store Appointment objects
    private List<Appointment> appointments = new ArrayList<>();

    // Add a new appointment
    public void addAppointment(String appointmentId, Date appointmentDate, String description) {

        // Check for duplicate appointment ID
        for (Appointment appointment : appointments) {
            if (appointment.getAppointmentId().equals(appointmentId)) {
                throw new IllegalArgumentException("Appointment ID already exists");
            }
        }

        // Create and add appointment if no duplicate found
        Appointment newAppointment = new Appointment(appointmentId, appointmentDate, description);
        appointments.add(newAppointment);
    }

    // Delete appointment by ID
    public void deleteAppointment(String appointmentId) {

        boolean removed = appointments.removeIf(
            appointment -> appointment.getAppointmentId().equals(appointmentId)
        );

        if (!removed) {
            throw new IllegalArgumentException("Appointment ID not found");
        }
    }

    // Getter for test verification
    public List<Appointment> getAppointments() {
        return appointments;
    }

}
