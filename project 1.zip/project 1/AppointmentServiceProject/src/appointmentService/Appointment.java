package appointmentService;

import java.util.Date;

/*
 * The Appointment class to manage Appointment objects
 * 
 * - Stores appointmentId, appointmentDate, and a description
 * - appointmentId cannot be updated after creation
 * - appointmentDate cannot be in the past
 */

public class Appointment {

    // Class attributes
    private final String appointmentId; // cannot be changed later
    private Date appointmentDate;
    private String description;

    // Constructor with validation
    public Appointment(String appointmentId, Date appointmentDate, String description) {

        // appointmentId: must be non-null and no longer than 10 characters
        if (appointmentId == null || appointmentId.length() > 10) {
            throw new IllegalArgumentException("Invalid appointment ID");
        }

        // appointmentDate: must be non-null and cannot be in the past
        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Invalid appointment date");
        }

        // description: must be non-null and max 50 characters
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description");
        }

        // Values assigned after passing validation
        this.appointmentId = appointmentId;
        this.appointmentDate = appointmentDate;
        this.description = description;
    }

    // Getters
    public String getAppointmentId() {
        return appointmentId;
    }

    public Date getAppointmentDate() {
        return appointmentDate;
    }

    public String getDescription() {
        return description;
    }

    // Setters
    public void setAppointmentDate(Date appointmentDate) {
        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Invalid appointment date");
        }
        this.appointmentDate = appointmentDate;
    }

    public void setDescription(String description) {
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description");
        }
        this.description = description;
    }

}
