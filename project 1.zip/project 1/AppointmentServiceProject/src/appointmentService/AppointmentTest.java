package appointmentService;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.util.Date;
import java.util.Calendar;

public class AppointmentTest {

    // Helper method to get a valid future date
    private Date getFutureDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 1);  // 1 day in the future
        return cal.getTime();
    }

    // Helper method to get a past date
    private Date getPastDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -1);  // 1 day in the past
        return cal.getTime();
    }

    // Test creating a valid Appointment object
    @Test
    public void testValidAppointmentCreation() {
        Appointment appointment = new Appointment(
            "100",
            getFutureDate(),
            "Follow-up appointment"
        );

        assertEquals("100", appointment.getAppointmentId());
        assertEquals("Follow-up appointment", appointment.getDescription());
        assertNotNull(appointment.getAppointmentDate());
    }

 // if appointmentId is null, throw an exception
    @Test
    public void testAppointmentIdNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, getFutureDate(), "Follow-up appointment");
        });
    }

    // if appointmentId is longer than 10 characters, throw an exception
    @Test
    public void testAppointmentIdTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", getFutureDate(), "Follow-up appointment");
        });
    }

    // if appointmentDate is null, throw an exception
    @Test
    public void testAppointmentDateNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("100", null, "Follow-up appointment");
        });
    }

    // if appointmentDate is in the past, throw an exception
    @Test
    public void testAppointmentDateInPast() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("100", getPastDate(), "Follow-up appointment");
        });
    }

    // if description is null, throw an exception
    @Test
    public void testDescriptionNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("100", getFutureDate(), null);
        });
    }

    // if description is longer than 50 characters, throw an exception
    @Test
    public void testDescriptionTooLong() {
        String longDesc = "123456789012345678901234567890123456789012345678901"; // 51 chars

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("100", getFutureDate(), longDesc);
        });
    }

    // Test updating appointment date with a valid future date
    @Test
    public void testUpdateDateValid() {
        Appointment appointment = new Appointment("100", getFutureDate(), "Follow-up appointment");

        Date newDate = getFutureDate();
        appointment.setAppointmentDate(newDate);

        assertEquals(newDate, appointment.getAppointmentDate());
    }

    // Test updating appointment date with null (invalid)
    @Test
    public void testUpdateDateNull() {
        Appointment appointment = new Appointment("100", getFutureDate(), "Follow-up appointment");

        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setAppointmentDate(null);
        });
    }

    // Test updating appointment date with a past date (invalid)
    @Test
    public void testUpdateDatePast() {
        Appointment appointment = new Appointment("100", getFutureDate(), "Follow-up appointment");

        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setAppointmentDate(getPastDate());
        });
    }

    // Test updating description with valid text
    @Test
    public void testUpdateDescriptionValid() {
        Appointment appointment = new Appointment("100", getFutureDate(), "Follow-up appointment");

        appointment.setDescription("Updated description");

        assertEquals("Updated description", appointment.getDescription());
    }

    // Test updating description with null
    @Test
    public void testUpdateDescriptionNull() {
        Appointment appointment = new Appointment("100", getFutureDate(), "Follow-up appointment");

        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setDescription(null);
        });
    }

    // Test updating description with too long text
    @Test
    public void testUpdateDescriptionTooLong() {
        Appointment appointment = new Appointment("100", getFutureDate(), "Follow-up appointment");

        String longDesc = "123456789012345678901234567890123456789012345678901";

        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setDescription(longDesc);
        });
    }

}
