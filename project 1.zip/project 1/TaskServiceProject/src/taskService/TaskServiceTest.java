package taskService;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {

    // Test adding a valid task
    @Test
    public void testAddTaskSuccess() {
        TaskService service = new TaskService();

        service.addTask("T1", "Study", "Study for the exam");

        assertEquals(1, service.getTasks().size());
        assertEquals("Study", service.getTasks().get(0).getName());
    }

    // if taskId already exists, throw an exception
    @Test
    public void testAddTaskDuplicateId() {
        TaskService service = new TaskService();

        service.addTask("T1", "Study", "Study for the exam");

        assertThrows(IllegalArgumentException.class, () -> {
            service.addTask("T1", "Review", "Review notes");
        });
    }

    // Test deleting a task that exists
    @Test
    public void testDeleteTaskSuccess() {
        TaskService service = new TaskService();

        service.addTask("T1", "Study", "Study for the exam");
        service.deleteTask("T1");

        assertEquals(0, service.getTasks().size());
    }

    // if deleting a task that does not exist, throw an exception
    @Test
    public void testDeleteTaskNotFound() {
        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteTask("NO_TASK");
        });
    }

    // Test updating task name
    @Test
    public void testUpdateName() {
        TaskService service = new TaskService();

        service.addTask("T1", "Study", "Study for the exam");
        service.updateName("T1", "Review");

        assertEquals("Review", service.getTasks().get(0).getName());
    }

    // Test updating task description
    @Test
    public void testUpdateDescription() {
        TaskService service = new TaskService();

        service.addTask("T1", "Study", "Study for the exam");
        service.updateDescription("T1", "Review chapters 1 and 2");

        assertEquals("Review chapters 1 and 2",
                     service.getTasks().get(0).getDescription());
    }

    // if updating a task that does not exist, throw an exception
    @Test
    public void testUpdateNonExistingTask() {
        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateName("NO_TASK", "Review");
        });
    }
}
