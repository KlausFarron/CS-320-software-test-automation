package taskService;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskTest {

    // Test creating a valid Task object
    @Test
    public void testValidTaskCreation() {
        Task task = new Task("T123", "Study", "Study for the exam");

        assertEquals("T123", task.getTaskId());
        assertEquals("Study", task.getName());
        assertEquals("Study for the exam", task.getDescription());
    }

    // if taskId is null, throw an exception
    @Test
    public void testTaskIdNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Study", "Study for the exam");
        });
    }

    // if taskId longer than 10 characters, throw an exception
    @Test
    public void testTaskIdTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("TOO-LONG-ID-123", "Study", "Study for the exam");
        });
    }

    // if name is null, throw an exception
    @Test
    public void testNameNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("T123", null, "Study for the exam");
        });
    }

    // if name is too long, throw an exception
    @Test
    public void testNameTooLong() {
        String longName = "ThisNameIsWayTooLong123"; // longer than 20 chars

        assertThrows(IllegalArgumentException.class, () -> {
            new Task("T123", longName, "Study for the exam");
        });
    }

    // if description is null, throw an exception
    @Test
    public void testDescriptionNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("T123", "Study", null);
        });
    }

    // if description too long, throw an exception
    @Test
    public void testDescriptionTooLong() {
        String longDescription =
            "This description is definitely longer than fifty characters total.";

        assertThrows(IllegalArgumentException.class, () -> {
            new Task("T123", "Study", longDescription);
        });
    }

    // Test updating name with a valid value
    @Test
    public void testUpdateNameValid() {
        Task task = new Task("T123", "Study", "Study for the exam");

        task.setName("Review");
        assertEquals("Review", task.getName());
    }

    // Test updating description with a valid value
    @Test
    public void testUpdateDescriptionValid() {
        Task task = new Task("T123", "Study", "Study for the exam");

        task.setDescription("Review chapters 1 and 2");
        assertEquals("Review chapters 1 and 2", task.getDescription());
    }
}
