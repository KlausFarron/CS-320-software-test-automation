package taskService;

import java.util.ArrayList;
import java.util.List;

/*
 * The TaskService class manages Task objects.
 * 
 * - Add tasks with a unique ID
 * - Delete tasks by ID
 * - Update task by name and description
 */

public class TaskService {

    // List to store all tasks
    private List<Task> tasks = new ArrayList<>();

    // return list for testing
    public List<Task> getTasks() {
        return tasks;
    }

    // Add a new task (ID must be unique)
    public void addTask(String taskId, String name, String description) {
        
        // check for duplicate ID
        for (Task t : tasks) {
            if (t.getTaskId().equals(taskId)) {
                throw new IllegalArgumentException("Task ID already exists");
            }
        }

        // create new task and add to list
        Task newTask = new Task(taskId, name, description);
        tasks.add(newTask);
    }

    // Delete a task by ID
    public void deleteTask(String taskId) {

        boolean removed = tasks.removeIf(task -> task.getTaskId().equals(taskId));

        if (!removed) {
            throw new IllegalArgumentException("Task ID not found");
        }
    }

    // Update task name by ID
    public void updateName(String taskId, String newName) {

        for (Task t : tasks) {
            if (t.getTaskId().equals(taskId)) {
                t.setName(newName);
                return;
            }
        }

        throw new IllegalArgumentException("Task ID not found");
    }

    // Update task description by ID
    public void updateDescription(String taskId, String newDescription) {

        for (Task t : tasks) {
            if (t.getTaskId().equals(taskId)) {
                t.setDescription(newDescription);
                return;
            }
        }

        throw new IllegalArgumentException("Task ID not found");
    }
}
