package taskService;

/*
 * The Task class stores task information.
 * 
 * - taskId that cannot be changed after creation
 * - taskId with max length 10
 * - name that is max length 20
 * - description that is max length 50
 */

public class Task {

    // Class attributes
    private final String taskId;
    private String name;
    private String description;

    // Constructor with validation
    public Task(String taskId, String name, String description) {

        // taskId: must be non-null and max 10 characters
        if (taskId == null || taskId.length() > 10) {
            throw new IllegalArgumentException("Invalid task ID");
        }

        // name: must be non-null and max 20 characters
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Invalid name");
        }

        // description: must be non-null and max 50 characters
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description");
        }

        // assign values after passing validation
        this.taskId = taskId;
        this.name = name;
        this.description = description;
    }

    // Getters
    public String getTaskId() {
        return taskId;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    // Setters for updatable fields
    public void setName(String name) {
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Invalid name");
        }
        this.name = name;
    }

    public void setDescription(String description) {
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description");
        }
        this.description = description;
    }
}
